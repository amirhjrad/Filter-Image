#include "get_instr.h"

GetInstr::GetInstr(int argc, char* argv[]) 
{
    for (int i = 1; i < argc; i++) 
    {
        std::string arg = argv[i];
        if (arg[0] == FILTERS_SIGN) 
        {
            std::string filter = arg.substr(1);
            filters.push_back(filter);
            views.push_back(NOT_A_VIEW);
        } 
        else views[i/2-1] = arg;
    }
}

std::vector<std::string> GetInstr::getFilters() { return filters; }

std::vector<std::string> GetInstr::getViews() { return views; }