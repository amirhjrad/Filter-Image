#ifndef ADDS_H
#define ADDS_H
#include <vector>
#include <string>
std::vector<std::string> separateText(std::string text, char seperator);
#endif